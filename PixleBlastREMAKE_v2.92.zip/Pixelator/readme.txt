version 1.2 - 3/13/19 (in Chicago for Riot Fest)
	Colors are auto generated when the games starts to alter the backgrounds.  This still needs to be changed to generated for a new instance of each level.
	The Colors needs to be stepped up to be full color instead of the odd earthy tones that there currently is.  
	Shots need to be dropped to a normal level. Also, readme.txt was started. 
	
version 1.3 - 9/13/19 (in Chicago for Riot Fest)
	The level colors are now changing at ever level.  
	Maureen suggested that the colors are a little to much so we need to tone down the visuals.  Next addition will be the strafing function. 
	
version 1.4 - 9/17/19
	Level colors are now much better, there is still some black showing in the tiles that I want removed, but generally it is good.  Strafing is done and 
	working fine and the shots have been moved to work with that new feature.  Shots have also been throttled back both on distance and fire rate allowing 
	for some easy level ups.  NEXT FOCUS - heads up display... Diagonal moving enemies... power ups...
	
version 1.5 - 9/22/19 (While Sarah was in Seattle)
	The player now moves between levels and everything responds to the static GSM manager is now the master GSM of everything.  To continue with the heads
	up display, the playable window needs to be moved down a notch and the health bar, level, score and whatever else can be put in the blackspace above. 
	Then, we'll move onto Diagonal moving enemies and power ups. 
	
version 1.7 - 10/5/19
	I have to find a way to get this file to show in Eclipse... anyway ->
	The HUD is mostly implemented.  I'm still not sure where (0, 0) truly is so I'm using (22, -5) as where the HUD starts.  This is fine for now, but I'm sure 
	it'll make things intresting later on. The next move will be to put in the powerups and health additions since this game is wicked hard right now.  
	Overall I am liking this progress and I think there will be a lot of fun to be had once the gameplay is balanced.  