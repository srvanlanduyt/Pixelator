package hud;

import gameStates.GameStateManager;
import levels.Level;
import gfx.Colors;
import gfx.Font;
import gfx.Screen;

public class EnemiesLeft extends HUD {

	private int color = Colors.get(0, 0, 0, 555);
	private int scale = 1;
	
	private int x;
	private int y;
	private int xOffset;
	private int yOffset;
	
	public Level level;
	private String output = "0";
	
	public EnemiesLeft(GameStateManager gsm, Level level) {
		super(gsm);
		this.x = 280;
		this.y = 0;
		this.level = level;
	}

	public void tick() {	
		setEnemiesLeft();
		
	}

	private void setEnemiesLeft() {
		if (level == null) {
			System.out.println("level is null");
			System.exit(0);
		}
		int enemiesLeft = level.getMowerNum();
		output = Integer.toString(enemiesLeft) + " Left";
	}

	public void render(Screen screen) {
		xOffset = x + screen.getXOffset();
		yOffset = y + screen.getYOffset();
		if (output != null) {
			Font.render(output, screen, xOffset, yOffset, color, scale);
		}
	}
}
